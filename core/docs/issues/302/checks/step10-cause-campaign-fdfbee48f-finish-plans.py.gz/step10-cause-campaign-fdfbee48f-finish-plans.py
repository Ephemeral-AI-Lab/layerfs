import json,sqlite3
from pathlib import Path
out=Path('benchmark-results/fs-bench-pro/issue302-cause-plans-fdfbee48f')
(out/'sqlite-plan-first-failure.txt').write_text('Post-proof SQLite EXPLAIN failed: Incorrect number of bindings supplied. The current statement uses 2, and there are 1 supplied. No performance child rerun. Supply the object ID and pack ceiling required by the shipped query. PG plans had completed and disposable write schema had been dropped.\n')
r={'kind':'POST_PROOF_WARM_PLAN_DIAGNOSTIC','admission_eligible':False,'scope':'1000-file completed candidate; representative bounded parameters, not captured bind arrays; write plans on disposable copied schema with original constraints and FK, not timed result','plans':{},'write_schema_cleanup':'PASS','inventory':{'objects':2003,'canonical_bytes':20187652,'packs':100,'signatures':939,'groups':20},'sqlite_plans':{}}
for p in out.glob('*.json'):
 if p.name!='receipt.json':r['plans'][p.stem]=json.loads(p.read_text())
for n in [100,1000]:
 p=Path(f'benchmark-results/fs-bench-pro/issue302-cause-{n}-baseline-fdfbee48f')
 with sqlite3.connect(f'file:{p}/store.sqlite?mode=ro',uri=True) as db:
  db.execute('CREATE TEMP TABLE layerfs_read_scope(save_id INTEGER,publication INTEGER)');db.execute('INSERT INTO layerfs_read_scope VALUES(0,9223372036854775807)')
  rows=json.loads((p/'sqlite-work.json').read_text())['classes'];sql=next(x['sql_prefix'] for x in rows if x['phase']==1 and x['sql_prefix'].startswith('SELECT o.object_id') and x['calls']>100)
  key=db.execute('SELECT object_id FROM objects LIMIT 1').fetchone()[0]
  r['sqlite_plans'][str(n)]={'sql':sql,'plan':db.execute('EXPLAIN QUERY PLAN '+sql,(key,9223372036854775807)).fetchall()}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:{'planning_ms':v[0]['Planning Time'],'execution_ms':v[0]['Execution Time'],'node':v[0]['Plan']['Node Type']} for k,v in r['plans'].items()},indent=2));print(r['sqlite_plans'])

import json,re,collections,sys,shutil
from pathlib import Path
sys.path.insert(0,'core/benchmark/fs-bench-pro');import runner
from shared import phase7 as contract
base=Path('benchmark-results/fs-bench-pro');out=base/'issue302-roll-analysis-fff66f0e7';out.mkdir();r={'source':'fff66f0e7ddfab643bb3692e039883ec6ede6d48','performance':{},'not_run':['init10000','init100000','history-stride10','history-stride3','history-stride1'],'diagnostic100_not_run':'not prospectively selected for this hash treatment'}
for n in [100,1000]:
 arms={}
 for arm in ['baseline','candidate']:
  p=base/f'issue302-roll{n}-{arm}-fff66f0e7';runner.verify_run_manifest(p);arms[arm]=json.loads((p/'receipt.json').read_text());x=arms[arm]
  assert x['verification_status']==x['cache_status']==x['cleanup']['status']=='PASS';assert x['sample_count']==1
 b,c=arms['baseline'],arms['candidate'];r['performance'][str(n)]={'baseline_ns':b['comparison_ns'],'candidate_ns':c['comparison_ns'],'ratio':c['comparison_ns']/b['comparison_ns'],'delta_ns':c['comparison_ns']-b['comparison_ns'],'gate':contract.strict_gate(c,b,None),'baseline_bytes':b['storage_bytes'],'candidate_bytes':c['storage_bytes'],'baseline_child_ns':b['command_wall_ns'],'candidate_child_ns':c['command_wall_ns'],'baseline_verifier_ns':b['verification_wall_ns'],'candidate_verifier_ns':c['verification_wall_ns'],'proof':c['verification']['child'],'allocation':{'minio':c['storage']['minio']['allocated_bytes'],'C2':c['storage']['postgres']['C2_bytes'],'C5':c['storage']['postgres']['C5_bytes']}}
p=base/'issue302-roll-cause1000-candidate-fff66f0e7';runner.verify_run_manifest(p);receipt=json.loads((p/'receipt.json').read_text());s3=json.loads((p/'s3-work.json').read_text());pg=json.loads((p/'pg-work.json').read_text());stmt=json.loads((p/'pg-statements.json').read_text());saves=json.loads((p/'save-work.json').read_text());events=[json.loads(x)['event'] for x in (p/'minio-trace.jsonl').read_text().splitlines()];api={}
for name,method in [('s3.PutObject','PUT'),('s3.GetObject','GET')]:
 xs=[x for x in events if x['api']==name and re.fullmatch(r'/layerfs/cluster1/[0-9a-f]{64}',x['path'])];assert len(xs)==next(v['calls'] for v in s3 if v['method']==method);assert all(x['statusCode']==200 for x in xs)
 api[name]={'calls':len(xs),'distinct_keys':len({x['path'] for x in xs}),'server_sum_ns':sum(x['duration'] for x in xs)}
bulk=next(x for x in stmt if not x['toplevel'] and 'INSERT INTO "layerfs".object' in x['query'])
r['diagnostic']={'child':receipt['driver']['child'],'s3':s3,'pg_calls':{k:sum(x['calls'] for x in v['statements']) for k,v in pg.items()},'bulk_calls':bulk['calls'],'bulk_server_ns':round(bulk['total_exec_time']*1e6),'bulk_rows_returned_arrays':bulk['rows'],'save':{stage['stage']:sum(x['wall_ns'] for save in saves['saves'] for x in save if x['stage']==stage['stage']) for stage in saves['saves'][0]},'server_api':api,'trace':receipt['minio_trace'],'status':receipt['status'],'verification':receipt['verification_status'],'cache':receipt['residency']['status'],'cleanup':receipt['scratch_cleanup']}
assert r['diagnostic']['child']['root']=='a71b9151bb269cdc3e71d9424e36669edd7d78ed39f9055bc355cebd4d93ec2c';assert receipt['minio_trace']['omitted']==receipt['minio_trace']['invalid']==0
(out/'analysis.json').write_text(json.dumps(r,indent=2)+'\n');shutil.copy2('target/phase7-agent/analyze-roll.py',out/'analyze-roll.py');shutil.copy2('target/phase7-agent/run-roll-arm.py',out/'run-roll-arm.py')
print(json.dumps(r,indent=2))

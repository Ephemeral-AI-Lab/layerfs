import sys,json,sqlite3
from pathlib import Path
sys.path.insert(0,'core/benchmark/fs-bench-pro')
from shared.phase7 import services
out=Path('benchmark-results/fs-bench-pro/issue302-cause-plans-fdfbee48f');out.mkdir()
record={'kind':'POST_PROOF_WARM_PLAN_DIAGNOSTIC','admission_eligible':False,'scope':'1000-file completed candidate result; representative bounded parameters, not replay of captured bind arrays; write plans on disposable copied schema','plans':{}}
q=Path('core/crates/layerfs-metadata/sql/queries')
def run(name,sql,params=None):
 text=sql
 if params:
  for i in range(len(params),0,-1):text=text.replace('$'+str(i),params[i-1])
 text=text.replace('${schema}','"layerfs"')
 cmd='EXPLAIN (ANALYZE, BUFFERS, WAL, TIMING OFF, FORMAT JSON) '+text
 (out/(name+'.sql')).write_text(cmd)
 result=json.loads(services.postgres_sql(cmd));record['plans'][name]=result
 (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 return result
ids=json.loads(services.postgres_sql("SELECT json_agg(encode(object_id,'hex')) FROM (SELECT object_id FROM layerfs.object ORDER BY object_id LIMIT 256) s;"))
record['inventory']=json.loads(services.postgres_sql("SELECT json_build_object('objects',(SELECT count(*) FROM layerfs.object),'canonical_bytes',(SELECT sum(canonical_length) FROM layerfs.object),'packs',(SELECT count(*) FROM layerfs.pack),'signatures',(SELECT count(*) FROM layerfs.content_signature),'groups',(SELECT count(*) FROM layerfs.metadata_value_group));"))
record['parameters']={'locate_hit_ids':ids,'missing_count':256,'scope':'256 real existing IDs and 256 distinct missing IDs; actual production bind arrays not captured'}
array=lambda xs:'ARRAY['+','.join("decode('"+v+"','hex')" for v in xs)+']::bytea[]'
run('locate-256-hit',(q/'storage/locate.sql').read_text(),[array(ids)])
run('locate-256-miss',(q/'storage/locate.sql').read_text(),[array([f'{n:064x}' for n in range(1,257)])])
run('signatures',(q/'storage/signatures.sql').read_text())
run('value-groups-page',(q/'storage/value_groups_page.sql').read_text(),['1','256'])
run('history-meta',(q/'history/meta.sql').read_text())
run('history-definition',(q/'history/definition.sql').read_text(),["'layerfs'","ARRAY['history_meta','layer_stack','layer','commit','branch','workspace_stage','scope_allocator']::text[]"])
setup='''CREATE SCHEMA issue302_explain;
CREATE TABLE issue302_explain.pack (LIKE layerfs.pack INCLUDING ALL);
INSERT INTO issue302_explain.pack SELECT * FROM layerfs.pack;
CREATE TABLE issue302_explain.object (LIKE layerfs.object INCLUDING ALL);
ALTER TABLE issue302_explain.object ADD FOREIGN KEY(pack_id) REFERENCES issue302_explain.pack(pack_id);
INSERT INTO issue302_explain.object SELECT * FROM layerfs.object;
'''
(out/'write-schema-setup.sql').write_text(setup);services.postgres_sql(setup)
pack=services.postgres_sql('SELECT min(pack_id) FROM issue302_explain.pack;').strip()
# Exercise production nested INSERT exactly, with new ID, copied real row fields/constraints.
fields='object_id,role,canonical_length,pack_id,group_number,record_number'
insert=f"INSERT INTO issue302_explain.object({fields}) VALUES (decode('{'ff'*32}','hex'),1,100,{pack},0,0) ON CONFLICT(object_id) DO NOTHING RETURNING object_id"
cmd='BEGIN; EXPLAIN (ANALYZE, BUFFERS, WAL, TIMING OFF, FORMAT JSON) '+insert+'; ROLLBACK;'
(out/'object-insert-one.sql').write_text(cmd);raw=services.postgres_sql(cmd);record['plans']['object-insert-one']=json.loads(raw[raw.index('['):raw.rindex(']')+1]);(out/'object-insert-one.json').write_text(json.dumps(record['plans']['object-insert-one'],indent=2)+'\n')
# Same production INSERT conflict branch with actual existing copied ID, not a changed bulk algorithm.
insert=f"INSERT INTO issue302_explain.object({fields}) SELECT {fields} FROM issue302_explain.object ORDER BY object_id LIMIT 1 ON CONFLICT(object_id) DO NOTHING RETURNING object_id"
cmd='BEGIN; EXPLAIN (ANALYZE, BUFFERS, WAL, TIMING OFF, FORMAT JSON) '+insert+'; ROLLBACK;'
(out/'object-insert-conflict.sql').write_text(cmd);raw=services.postgres_sql(cmd);record['plans']['object-insert-conflict']=json.loads(raw[raw.index('['):raw.rindex(']')+1]);(out/'object-insert-conflict.json').write_text(json.dumps(record['plans']['object-insert-conflict'],indent=2)+'\n')
services.postgres_sql('DROP SCHEMA issue302_explain CASCADE;');record['write_schema_cleanup']='PASS'
record['sqlite_plans']={}
for n in [100,1000]:
 p=Path(f'benchmark-results/fs-bench-pro/issue302-cause-{n}-baseline-fdfbee48f')
 with sqlite3.connect(f'file:{p}/store.sqlite?mode=ro',uri=True) as db:
  db.execute('CREATE TEMP TABLE layerfs_read_scope(save_id INTEGER,publication INTEGER)');db.execute('INSERT INTO layerfs_read_scope VALUES(0,9223372036854775807)')
  d=json.loads((p/'sqlite-work.json').read_text());r=next(r for r in d['classes'] if r['phase']==1 and r['sql_prefix'].startswith('SELECT o.object_id') and r['calls']>100)
  sql=r['sql_prefix'];key=db.execute('SELECT object_id FROM objects LIMIT 1').fetchone()[0]
  record['sqlite_plans'][str(n)]=db.execute('EXPLAIN QUERY PLAN '+sql,(key,)).fetchall()
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'inventory':record['inventory'],'plans':{k:{'planning_ms':v[0]['Planning Time'],'execution_ms':v[0]['Execution Time'],'node':v[0]['Plan']['Node Type']} for k,v in record['plans'].items()},'sqlite_plans':record['sqlite_plans']},indent=2))

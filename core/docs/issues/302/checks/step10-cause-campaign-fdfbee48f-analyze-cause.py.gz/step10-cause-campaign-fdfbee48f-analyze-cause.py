import json,re
from pathlib import Path
base=Path('benchmark-results/fs-bench-pro');campaign=base/'issue302-cause-campaign-fdfbee48f'
def fnv(text):
 h=0xcbf29ce484222325
 for b in text.encode():h=((h^b)*0x100000001b3)&0xffffffffffffffff
 return f'{h:016x}'
queries={fnv(p.read_text()):str(p) for p in Path('core/crates/layerfs-metadata/sql/queries').rglob('*.sql')}
rows={}
for n in [100,1000]:
 for arm in ['baseline','candidate']:
  p=base/f'issue302-cause-{n}-{arm}-fdfbee48f';r=json.loads((p/'receipt.json').read_text());child=r['driver']['child'];timing=json.loads((p/'timing.json').read_text())
  row={'operation_ns':child['operation_ns'],'cpu_ns':child['cpu_ns'],'command_ns':r['driver']['wall_ns'],'verifier_ns':r['verification']['wall_ns'],'status':r['status'],'verification':r['verification_status'],'cleanup':r['scratch_cleanup'],'residency':r['residency'],'root':child['root'],'phases':child['phases'],'timer_ns':timing['elapsed_ns'],'steps':{c['name']:c['elapsed_ns'] for c in timing['children']},'paths':r['verification']['child']['paths'],'sampled_files':r['verification']['child']['sampled_files'],'sampled_bytes':r['verification']['child']['sampled_bytes']}
  if arm=='baseline':
   d=json.loads((p/'sqlite-work.json').read_text());rs=[v for v in d['classes'] if v['phase']==1]
   row['sqlite_omitted']=d['omitted'];row['sqlite']={}
   for owner in [2,5]:
    vals=[v for v in rs if v['owner']==owner];obj={k:sum(v[k] for v in vals) for k in ['calls','vm_steps','fullscan_steps','sorts','reprepare','step_calls','step_ns','exec_calls','exec_ns']}
    obj['begin']=sum(v['calls'] for v in vals if v['sql_prefix'].strip().upper().startswith('BEGIN'));obj['commit']=sum(v['calls'] for v in vals if v['sql_prefix'].strip().upper().startswith('COMMIT'));obj['rollback']=sum(v['calls'] for v in vals if v['sql_prefix'].strip().upper().startswith('ROLLBACK'))
    obj['object_insert_calls']=sum(v['calls'] for v in vals if v['sql_prefix'].strip().startswith('INSERT INTO objects '));obj['top_vm']=sorted(vals,key=lambda v:v['vm_steps'],reverse=True)[:12];row['sqlite'][str(owner)]=obj
   row['canonical']=r['canonical'];row['storage_bytes']=r['storage_bytes']
  else:
   row['bootstrap_ns']=child['bootstrap_ns'];row['pg']={}
   work=json.loads((p/'pg-work.json').read_text())
   for owner,vals in work.items():
    for v in vals['statements']:v['source']=queries.get(v['sql_id'],'UNMAPPED')
    row['pg'][owner]={'omitted':vals['omitted'],'totals':{k:sum(v[k] for v in vals['statements']) for k in ['calls','mutating_calls','caller_ns','queue_ns','driver_ns']},'statements':vals['statements']}
   stmt=json.loads((p/'pg-statements.json').read_text());top=[v for v in stmt if v['toplevel'] and ('"layerfs".' in v['query'] or v['query'] in ['BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY','BEGIN','COMMIT','ROLLBACK'] or 'pg_catalog.' in v['query'])]
   # Exclude observation snapshot/reset entries by exact product templates/categories.
   row['pg_top']=top;row['pg_nested']=[v for v in stmt if not v['toplevel']];row['pg_top_calls']=sum(v['calls'] for v in top);row['pg_top_exec_ms']=sum(v['total_exec_time'] for v in top);row['pg_top_plan_ms']=sum(v['total_plan_time'] for v in top)
   row['s3']=json.loads((p/'s3-work.json').read_text());row['save']=json.loads((p/'save-work.json').read_text());row['save_total']={v['stage']:sum(next(t['wall_ns'] for t in save if t['stage']==v['stage']) for save in row['save']['saves']) for v in row['save']['saves'][0]}
   row['wal_delta']={k:r['after']['wal'][k]-r['before']['wal'][k] for k in r['after']['wal'] if isinstance(r['after']['wal'][k],(int,float))};row['db_delta']={k:r['after']['database'][k]-r['before']['database'][k] for k in r['after']['database'] if isinstance(r['after']['database'][k],(int,float))}
   row['statement_info']=r['after']['statement_info'];row['storage_bytes']=r['storage']['total_bytes'];row['allocation']={'minio':r['storage']['minio']['allocated_bytes'],'C2':r['storage']['postgres']['C2_bytes'],'C5':r['storage']['postgres']['C5_bytes']}
  rows[f'{n}-{arm}']=row
(campaign/'analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
for k,r in rows.items():
 print(k,{p:r[p] for p in ['operation_ns','cpu_ns','command_ns','verifier_ns','status','verification','cleanup','storage_bytes']})
 if 'sqlite' in r:
  print('sqlite',{o:{k:v for k,v in t.items() if k!='top_vm'} for o,t in r['sqlite'].items()})
 else:
  print('PG', {o:t['totals'] for o,t in r['pg'].items()},'TOP',r['pg_top_calls'],r['pg_top_exec_ms'],r['pg_top_plan_ms'])
  print('PG_WORK',[(Path(v['source']).stem,v['calls'],v['caller_ns']) for o in r['pg'].values() for v in o['statements']])
  print('NESTED',{k:sum(v[k] for v in r['pg_nested']) for k in ['calls','total_exec_time','plans']})
  print('WAL',r['wal_delta'],'DBTX',r['db_delta']['xact_commit'],r['db_delta']['xact_rollback'],'INFO',r['statement_info'])
  print('SAVE',r['save_total'])

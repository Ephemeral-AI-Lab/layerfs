import json,re,collections,sys
from pathlib import Path
sys.path.insert(0,'core/benchmark/fs-bench-pro')
import runner
from shared import phase7 as contract
root=Path('benchmark-results/fs-bench-pro');out=root/'issue302-opt-analysis-a7ebff1b4';out.mkdir()
r={'kind':'OPTIMIZATION_RESULT','source':'a7ebff1b4ae4735e196721ba2a6e34428e04593a','performance':{},'diagnostics':{},'not_run':['phase7-init-10000-direct-engines-v2','phase7-init-100000-direct-engines-v2','phase7-history-stride10-direct-engines-v1','phase7-history-stride3-direct-engines-v1','phase7-history-stride1-direct-engines-v1']}
for n in [100,1000]:
 arms={}
 for arm in ['baseline','candidate']:
  p=root/f'issue302-opt{n}-{arm}-a7ebff1b4';runner.verify_run_manifest(p);arms[arm]=json.loads((p/'receipt.json').read_text())
  assert arms[arm]['verification_status']==arms[arm]['cache_status']=='PASS'
  assert arms[arm]['sample_count']==1 and arms[arm]['cleanup']['status']=='PASS'
 b,c=arms['baseline'],arms['candidate'];r['performance'][str(n)]={'baseline_ns':b['comparison_ns'],'candidate_ns':c['comparison_ns'],'delta_ns':c['comparison_ns']-b['comparison_ns'],'ratio':c['comparison_ns']/b['comparison_ns'],'gate':contract.strict_gate(c,b,None),'baseline_storage':b['storage_bytes'],'candidate_storage':c['storage_bytes'],'baseline_command_ns':b['command_wall_ns'],'candidate_command_ns':c['command_wall_ns'],'baseline_verifier_ns':b['verification_wall_ns'],'candidate_verifier_ns':c['verification_wall_ns'],'proof':c['verification']['child'],'allocation':{'minio':c['storage']['minio']['allocated_bytes'],'C2':c['storage']['postgres']['C2_bytes'],'C5':c['storage']['postgres']['C5_bytes']}}
 p=root/f'issue302-opt-cause{n}-candidate-a7ebff1b4';runner.verify_run_manifest(p);rec=json.loads((p/'receipt.json').read_text());s3=json.loads((p/'s3-work.json').read_text());pg=json.loads((p/'pg-work.json').read_text());stat=json.loads((p/'pg-statements.json').read_text());saves=json.loads((p/'save-work.json').read_text());events=[json.loads(line)['event'] for line in (p/'minio-trace.jsonl').read_text().splitlines()]
 api={};putpaths=set()
 for name,method in [('s3.PutObject','PUT'),('s3.GetObject','GET')]:
  xs=[x for x in events if x.get('api')==name and re.fullmatch(r'/layerfs/cluster1/[0-9a-f]{64}',x.get('path',''))]
  expected=next(x['calls'] for x in s3 if x['method']==method);assert len(xs)==expected,(n,name,len(xs),expected)
  assert all(x['statusCode']==200 for x in xs)
  api[name]={'calls':len(xs),'sum_server_ns':sum(x['duration'] for x in xs),'min_ns':min(x['duration'] for x in xs),'max_ns':max(x['duration'] for x in xs),'distinct_paths':len({x['path'] for x in xs})}
  if method=='PUT':putpaths={x['path'] for x in xs}
 # Map measured PUT keys to temporary write UUIDs from RenameData. Other OS
 # traces may remain unattributed; never report the whole service as exact disk work.
 tokens=set()
 for x in events:
  if x.get('api')=='storage.RenameData':
   parts=x['path'].split()
   if len(parts)==5 and '/'+parts[3]+'/'+parts[4] in putpaths:tokens.add(parts[1]+'/'+parts[2])
 disk={}
 for name in ['storage.CreateFile','os.Fdatasync','storage.RenameData']:
  xs=[x for x in events if x.get('api')==name];matched=[x for x in xs if (name=='storage.RenameData' and '/'+x['path'].split()[-2]+'/'+x['path'].split()[-1] in putpaths) or any(token in x['path'] for token in tokens)]
  disk[name]={'all_calls':len(xs),'all_sum_ns':sum(x['duration'] for x in xs),'matched_calls':len(matched),'matched_sum_ns':sum(x['duration'] for x in matched)}
 bulk=[x for x in stat if not x['toplevel'] and 'INSERT INTO "layerfs".object' in x['query']];assert len(bulk)==1
 totals={owner:{k:sum(x[k] for x in rows['statements']) for k in ['calls','mutating_calls','caller_ns','queue_ns','driver_ns']} for owner,rows in pg.items()}
 r['diagnostics'][str(n)]={'operation_ns':rec['driver']['child']['operation_ns'],'bootstrap_ns':rec['driver']['child']['bootstrap_ns'],'cpu_ns':rec['driver']['child']['cpu_ns'],'root':rec['driver']['child']['root'],'pg':totals,'bulk_calls':bulk[0]['calls'],'bulk_server_ns':round(bulk[0]['total_exec_time']*1000000),'bulk_returned_aggregate_rows':bulk[0]['rows'],'s3':s3,'save':{stage['stage']:sum(x['wall_ns'] for save in saves['saves'] for x in save if x['stage']==stage['stage']) for stage in saves['saves'][0]},'server_api':api,'server_storage':disk,'trace':rec['minio_trace'],'command_ns':rec['driver']['wall_ns'],'verifier_ns':rec['verification']['wall_ns'],'verification':rec['verification_status'],'cache':rec['residency']['status'],'cleanup':rec['scratch_cleanup']}
 # Compare only reproducible work counts against the earlier cause receipt;
 # the newly added MinIO profiler prevents a before/after timing claim.
 old=root/f'issue302-cause-{n}-candidate-fdfbee48f';before=json.loads((old/'s3-work.json').read_text());r['diagnostics'][str(n)]['before_s3_counts']={x['method']:x['calls'] for x in before}
 assert rec['minio_trace']['omitted']==rec['minio_trace']['invalid']==0
 assert r['diagnostics'][str(n)]['root']==json.loads((old/'receipt.json').read_text())['driver']['child']['root']
(p:=out/'analysis.json').write_text(json.dumps(r,indent=2)+'\n')
print('AUDIT PASS',r['performance']);print('DIAGNOSTIC', {n:{'pg':d['pg'],'bulk_calls':d['bulk_calls'],'bulk_ns':d['bulk_server_ns'],'api':d['server_api'],'disk':d['server_storage'],'save':d['save']} for n,d in r['diagnostics'].items()})

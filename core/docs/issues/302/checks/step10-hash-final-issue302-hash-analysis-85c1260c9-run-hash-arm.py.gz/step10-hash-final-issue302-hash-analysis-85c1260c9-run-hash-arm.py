import sys,subprocess,time,json
from pathlib import Path
n,arm,kind=sys.argv[1:]
root=Path.cwd();label=f'issue302-hash{n}-{arm}-85c1260c9' if kind=='speed' else 'issue302-hash-cause1000-candidate-85c1260c9'
case=f'phase7-init-{n}-direct-engines-v2' if kind=='speed' else 'phase7-init-work-1000-v1'
(root/'target/phase7-agent'/f'{label}-report-contract.txt').write_text((root/'benchmark_agent_report.md').read_text())
cmd=['python3','core/benchmark/fs-bench-pro/runner.py','run','--case',case,'--arm',arm,'--out',str(root/'benchmark-results/fs-bench-pro'/label)]
if arm=='baseline':cmd+=['--baseline-root',str(root/'target/phase7-baseline/layerfs')]
budget=15 if kind=='speed' else 25;t=time.monotonic_ns();timed_out=False
try:r=subprocess.run(cmd,timeout=budget);code=r.returncode
except subprocess.TimeoutExpired:code=None;timed_out=True
record={'command':cmd,'wall_ns':time.monotonic_ns()-t,'budget_ns':budget*1000000000,'includes':'runner build/setup/fresh service lifecycle/product child/separate proof/storage collection','speed_comparison':'only inner declared operation; proof/setup never added','exit_code':code,'timed_out':timed_out}
p=root/'benchmark-results/fs-bench-pro/issue302-hash-freeze-85c1260c9'/f'{label}-envelope.json';p.write_text(json.dumps(record,indent=2)+'\n');print('OUTER',record['wall_ns'],record['budget_ns'],code)

CREATE SCHEMA issue302_explain;
CREATE TABLE issue302_explain.pack (LIKE layerfs.pack INCLUDING ALL);
INSERT INTO issue302_explain.pack SELECT * FROM layerfs.pack;
CREATE TABLE issue302_explain.object (LIKE layerfs.object INCLUDING ALL);
ALTER TABLE issue302_explain.object ADD FOREIGN KEY(pack_id) REFERENCES issue302_explain.pack(pack_id);
INSERT INTO issue302_explain.object SELECT * FROM layerfs.object;

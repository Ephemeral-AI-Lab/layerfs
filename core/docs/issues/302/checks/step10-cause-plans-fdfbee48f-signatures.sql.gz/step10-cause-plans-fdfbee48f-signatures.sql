EXPLAIN (ANALYZE, BUFFERS, WAL, TIMING OFF, FORMAT JSON) SELECT slot,stamp,object_id,signature FROM "layerfs".content_signature ORDER BY stamp,slot;

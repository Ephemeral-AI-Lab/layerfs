#!/usr/bin/env python3
"""Record exact compiler types using parent-qualified DWARF DIE paths."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

TARGETS = [
    'layerfs_workspace::filesystem::create::Creation',
    'layerfs_workspace::runtime::coherence::MutationOrigin',
    'layerfs_workspace::runtime::coherence::ProjectionMutationPermit',
    'layerfs_workspace::runtime::coherence::ProjectionReplyPermit',
    'layerfs_workspace::runtime::coherence::ProjectionState',
    'layerfs_workspace::types::CoherenceFailure',
    'layerfs_workspace::types::CoherenceStatus',
    'layerfs_workspace::types::MutationReceipt',
    'layerfs_workspace::runtime::state::Node',
    'layerfs_workspace::runtime::state::Handle',
    'layerfs_workspace::runtime::state::State',
    'layerfs_workspace::types::ReadReply',
    'layerfs_workspace::overlay::pieces::Inode',
]


def parse(raw):
    stack = []
    current = None
    found = {name: [] for name in TARGETS}

    def finish():
        if current is None:
            return
        if current["tag"] == "compile_unit":
            stack.clear()
            return
        while stack and stack[-1][0] >= current["indent"]:
            stack.pop()
        name = current.get("name")
        if not name:
            return
        path = "::".join([parent[1] for parent in stack] + [name])
        if path in found and "bytes" in current:
            entry = {key: current[key] for key in ("offset", "bytes", "alignment") if key in current}
            if entry not in found[path]:
                found[path].append(entry)
        stack.append((current["indent"], name))

    for line in raw.splitlines():
        tag = re.match(r"^(0x[0-9a-f]+):( +)DW_TAG_(\w+)", line)
        if tag:
            finish()
            current = {"offset": tag[1], "indent": len(tag[2]), "tag": tag[3]}
            continue
        if current is None:
            continue
        name = re.search(r'DW_AT_name\s+\("([^"\n]*)"\)', line)
        if name:
            current["name"] = name[1]
        for label, key in (("byte_size", "bytes"), ("alignment", "alignment")):
            value = re.search(r"DW_AT_" + label + r"\s+\((0x[0-9a-f]+|[0-9]+)\)", line)
            if value:
                current[key] = int(value[1], 0)
    finish()
    for path, entries in found.items():
        if not entries:
            continue
        assert len({(item["bytes"], item.get("alignment")) for item in entries}) == 1, path
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    args = parser.parse_args()
    binary = args.binary.resolve()
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    assert digest == args.sha256
    command = ["dwarfdump", "--show-parents"]
    command += ["--name=" + name.rsplit("::", 1)[1] for name in TARGETS]
    command += [str(binary)]
    completed = subprocess.run(command, check=True, capture_output=True, text=True, timeout=60)
    assert not completed.stderr, completed.stderr
    raw_path = args.prefix.with_suffix(".txt")
    with raw_path.open("x") as file:
        file.write(completed.stdout)
    assert "file format elf64-littleaarch64" in completed.stdout.splitlines()[0]
    types = parse(completed.stdout)
    result = {
        "binary": str(binary), "binary_sha256": digest, "command": command,
        "raw_dwarf": str(raw_path.resolve()),
        "raw_dwarf_sha256": hashlib.sha256(completed.stdout.encode()).hexdigest(),
        "capture_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "method": "Exact full DIE parent paths; Linux AArch64 compiler layout only; no heap/RSS/cgroup/stack-peak claim",
        "types": types,
        "not_found": [path for path, entries in types.items() if not entries],
    }
    with args.prefix.with_suffix(".json").open("x") as file:
        json.dump(result, file, indent=2)
        file.write("\n")
    print(json.dumps({path: (entries[0]["bytes"] if entries else None) for path, entries in types.items()}, indent=2))


if __name__ == "__main__":
    main()

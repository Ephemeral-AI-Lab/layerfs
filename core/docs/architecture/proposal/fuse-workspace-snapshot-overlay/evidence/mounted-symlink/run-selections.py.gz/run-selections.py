from pathlib import Path
import hashlib,json,os,signal,subprocess,time
root=Path.cwd();p=root/'core/target/pair1-evidence/mounted-symlink';env=os.environ.copy();env.update(DOCKER_CONTEXT='desktop-linux',LAYERFS_CONSTRUCTION_WORKERS='1')
freeze=json.loads((p/'source-freeze-02.json').read_text())
for f,h in {**freeze['source_inputs_sha256'],**freeze['caller_inputs_sha256']}.items():assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h,f
host=json.loads((p/'host-binaries-01.json').read_text())['path'];bins=json.loads((p/'test-binaries-01.json').read_text())['binaries']
rows=[('mounted_symlink',c,'mounted_symlink_route.py') for c in ('kernel','visibility_successor','permit','notification_failure')]+[('symlink','refusals','symlink_route.py'),('mounted_mkdir','notification_failure','mounted_mkdir_route.py'),('mounted_create','kernel','mounted_create_route.py')]
for binary,case,driver in rows:
 name=f'{binary}-{case}-01';out=p/name
 cmd=['python3',str(root/'core/crates/layerfs-workspace/tests'/driver),'--case',case,'--fixture',str(root/'core/target/pair1-evidence/fixtures/large-edit-master-01/result.json'),'--binaries',host,'--test-binary',bins[binary]['path'],'--image','sha256:e51d0265072d2d9d5d320f6a44dde6b9ef13653b035098febd68cce8fa7c0bc4','--output',str(out)]
 with (p/f'{name}-driver.log').open('xb') as log:
  start=time.monotonic();child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);forced=False
  try:code=child.wait(timeout=60)
  except subprocess.TimeoutExpired:
   forced=True;os.killpg(child.pid,signal.SIGTERM);code=child.wait(timeout=10)
  wall=time.monotonic()-start
 result=dict(name=name,command=cmd,exit_code=code,complete_wall_seconds=wall,forced_external_cleanup=forced,source_freeze='source-freeze-02.json')
 with (p/f'{name}-command.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result),flush=True)
 if code or forced:raise SystemExit(code or 1)

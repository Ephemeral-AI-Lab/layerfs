from pathlib import Path
from collections import defaultdict
import hashlib, importlib.util, json, re, subprocess, sys

root = Path.cwd()
packet = root / 'core/docs/architecture/proposal/fuse-workspace-snapshot-overlay'
output = packet / 'evidence/construct-symlink/source-loc.json'
assert not output.exists(), 'new evidence only'
historical = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (packet/'evidence').rglob('source-loc.json')}
parent = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert parent == '5ed91aaca38dc54e145753a6844b12e6baf30abd'
counter = root/'tools/production_loc.py'
blob = subprocess.check_output(['git','hash-object',str(counter)],text=True).strip()
assert blob == 'b5b9617d08204977176302311e0b2c72a811b420'
spec = importlib.util.spec_from_file_location('production_loc',counter)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
sys.path.insert(0,str(root/'core/crates/layerfs-daemon/tests'))
import mounted_read
seal = mounted_read.product_inputs()
assert seal == 'ab247a3da4597e0429239b2b6b8a912d4455e83d380172300fabe947c913a80a'
rows = module.per_file(root)['files']
scan = module.scan(root)
subprocess.run(['git','diff','--quiet',parent,'--','crates'],check=True)
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates']).strip()
reference_tree = subprocess.check_output(['git','rev-parse',parent+':crates'],text=True).strip()

def totals(selected):
    return {'production_loc':sum(r['production_loc'] for r in selected),
            'physical_lines':sum(r['physical_lines'] for r in selected),
            'files':len(selected)}

scopes = {}
folders = defaultdict(list)
for scope in ('core','reference'):
    selected = [r for r in rows if r['scope']==scope]
    scopes[scope] = totals(selected)
    scopes[scope]['crates'] = {crate:totals([r for r in selected if r['crate']==crate]) for crate in sorted({r['crate'] for r in selected})}
    assert scopes[scope]['production_loc']==scan['scopes'][scope]['lines']
    assert scopes[scope]['files']==scan['scopes'][scope]['files']
    base = Path('core/crates' if scope=='core' else 'crates')
    for row in selected:
        path = Path(row['path']).parent
        while path!=base.parent:
            folders[(scope,str(path))].append(row)
            path = path.parent
folder_rows=[dict(scope=scope,path=path,**totals(selected)) for (scope,path),selected in sorted(folders.items())]
combined = totals(rows)
assert combined['production_loc']==scan['combined']
report={
    'files':rows,'folders':folder_rows,'scopes':scopes,'combined':combined,
    'source_commit':None,'implementation_parent':parent,'product_input_seal':seal,
    'reference_tree':reference_tree,
    'source_state':'Frozen working-tree production source after the implementation parent; commit pending. This is not a count of the unchanged parent commit. The core product_input_seal includes all core production inputs; unchanged reference source is pinned by reference_tree.',
    'counter_blob':blob,
    'method':'Unchanged tools/production_loc.py per_file() and scan() on the frozen source named by product_input_seal and reference_tree. CLI equivalents: python3 tools/production_loc.py --root <source-snapshot> --files and --json. After committing, archive that exact commit\'s crates and core/crates paths. Nonblank/noncomment production Rust/runtime SQL; exclude tests including inline cfg(test), fixtures, examples, docs, tooling, manifests and generated output. Physical lines and recursive folder totals are separate.'
}

mdpath=packet/'31-source-map-and-loc.md'
md=mdpath.read_text()
md=re.sub(r'> Implementation parent: `[^`]+`\.',f'> Implementation parent: `{parent}`.',md)
md=re.sub(r'> Frozen production input seal: `[^`]+`\.',f'> Frozen production input seal: `{seal}`.',md)
md=re.sub(r'JSON includes all \d+ core and \d+ reference production files separately,',f"JSON includes all {scopes['core']['files']} core and {scopes['reference']['files']} reference production files separately,",md)
md=md.replace('[Current per-file machine-readable inventory](evidence/mounted-create/source-loc.json)', '[Current per-file machine-readable inventory](evidence/construct-symlink/source-loc.json)', 1)
md=re.sub(r'> Exact implementation commit:.*', '> Exact implementation commit: **pending**; counts bind the frozen production seal above.', md, count=1)
responsibilities={
'layerfs-daemon':'Process/configuration, authenticated control and one current lifecycle owner shared with shutdown',
'layerfs-fuse':'Linux kernel projection, replies, mount/session ownership',
'layerfs-workspace':'Shared portable filesystem semantics, private backing, capture and Commit orchestration',
'layerfs-bridge':'Logical operation contract, Source, authorization identity and native framing/delivery',
'layerfs-service':'Authorized operation dispatch and service-local C1/C2/C5 assembly',
'layerfs-content':'C1 canonical content/filesystem algorithms and attributes',
'layerfs-storage':'C2 Store, physical persistence and writer admission',
'layerfs-history':'C5 stages, Branch/Commit/Layer catalog transactions',
'layerfs-telemetry':'Shared bounded operation observation/output',
}
for crate,responsibility in responsibilities.items():
    t=scopes['core']['crates'][crate]
    md=re.sub(rf'^\| `{crate}` \|.*$',f"| `{crate}` | {t['production_loc']} | {t['physical_lines']} | {t['files']} | {responsibility} |",md,flags=re.M)
c=scopes['core']; r=scopes['reference']; a=combined
md=re.sub(r'Core total:.*?Root `crates/`',f"Core total: **{c['production_loc']} P / {c['physical_lines']} L**, across {c['files']} files. Reference total:\n**{r['production_loc']} P / {r['physical_lines']} L**, across {r['files']} files. Combined: **{a['production_loc']} P / {a['physical_lines']} L**. Root `crates/`",md,flags=re.S)
md=md.replace('## Mounted regular-file creation', '## Shared symlink-content construction\n\nBridge adds one bounded target constructor using the existing Saved result and\ncontent-construction grant. Service uses the existing C1 symlink builder and\nSaveHandoff. No new response type, inode attachment or history operation is added;\nsee [45](45-construct-symlink.md).\n\n## Mounted regular-file creation', 1)

def line_totals(selected):
    t=totals(selected)
    return f"[P={t['production_loc']}; L={t['physical_lines']}; N={t['files']}]"

def tree(crate):
    base=Path('core/crates')/crate
    selected=[r for r in rows if r['scope']=='core' and r['crate']==crate]
    lines=[str(base)+'/  '+line_totals(selected)]
    def recurse(directory,prefix):
        files={Path(r['path']).name:r for r in selected if Path(r['path']).parent==directory}
        directories=sorted({Path(r['path']).relative_to(directory).parts[0] for r in selected if Path(r['path']).is_relative_to(directory) and len(Path(r['path']).relative_to(directory).parts)>1})
        children=[(name,True) for name in directories]+[(name,False) for name in sorted(files)]
        for i,(name,is_dir) in enumerate(children):
            last=i==len(children)-1
            branch='`-- ' if last else '|-- '
            if is_dir:
                descendant=directory/name
                contained=[r for r in selected if Path(r['path']).is_relative_to(descendant)]
                lines.append(prefix+branch+name+'/  '+line_totals(contained))
                recurse(descendant,prefix+('    ' if last else '|   '))
            else:
                r=files[name]
                lines.append(prefix+branch+name+f"  [P={r['production_loc']}; L={r['physical_lines']}]")
    recurse(base,'')
    return '\n'.join(lines)
for crate in responsibilities:
    pattern=rf'(### {crate}\n\n```text\n).*?(\n```)'
    md,count=re.subn(pattern,lambda m:m.group(1)+tree(crate)+m.group(2),md,count=1,flags=re.S)
    assert count==1,crate
assert mounted_read.product_inputs()==seal,'product changed during count'
for p,digest in historical.items():
    assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest,p
output.parent.mkdir(parents=True,exist_ok=True)
output.write_text(json.dumps(report,indent=2)+'\n')
mdpath.write_text(md)
print(json.dumps({'seal':seal,'parent':parent,'scopes':scopes,'combined':combined,'core_folders':sum(r['scope']=='core' for r in folder_rows),'reference_folders':sum(r['scope']=='reference' for r in folder_rows),'historical_inventories_unchanged':len(historical)},indent=2))

## Pair 1 — fresh-streaming live results, and one new open blocker

Local commit `eb2fbd7633e1320315c316da02587b90f655bb39` (parent `9499012926f6`, not pushed).

The six registered Round49 selections have now run, one attempt each, serially, after re-verifying
all 494 source/caller hashes of the frozen product seal `ffa9fa10899063601d7520581f7db932644a9c45a34b2123fa895f012320da08`.

| Selection | Result |
| --- | --- |
| `fresh_stream mounted_dsh` | **PASS** 40.81 s complete |
| `fresh_stream captured_replay` | **FAIL** 1.13 s — new open blocker, below |
| `write envelope` | **PASS** 3.18 s |
| `create semantics` | **PASS** 1.39 s |
| `create successor` | **PASS** 1.34 s |
| `symlink semantics` | **PASS** 1.58 s |

`mounted_dsh` uploaded the pinned 18,259,144-byte preinstalled DSH file through the writable mounted
projection in 140 caller buffers of 128 KiB with SHA256 verified during the upload, then completed one
ConstructFile/Commit and one 4-byte EditFile/Commit against the prior content and metadata roots, with
the complete canonical digest checked and native close/teardown clean. 140 caller buffers are not a
kernel request count, and these are functional receipts with an undeclared cache state — not
performance evidence.

**New open blocker.** `captured_replay` fails at `fresh_stream.rs:387` from the **second** `refuse_extra`
call (line 441, after `commit_staged`): the +1 write returns `Capacity` and changes no observed state
(generation, revision, dirty inodes, nodes, handles and attributes all unchanged), but one native
`Inspect` is delivered before the refusal, and the caller asserts that a refusal appends no operation.
The pre-rebase refusal (line 424) passes, so the pre-G-completion refusal consumes nothing. A labelled
diagnostic run with the pre-existing `LAYERFS_NATIVE_DIAGNOSTIC_TRACE` facility places the failure at
line 441 and identifies the extra delivery. No product or caller source was changed, and no assertion
was relaxed to make the case pass. It needs reproduction through the public Workspace API and a decision:
must an over-limit refusal be decided before any native consultation, or is the caller oracle wrong to
require zero operations once the file carries an inherited canonical base?

This supersedes the "all six registered live selections are NOT_RUN" line in the budget-stop comment
above; that comment remains the historical receipt for the state at the budget stop. The four blockers
it lists are unchanged and still open: 128-row/32 KiB admission against 28,743 dirty identities and at
least 2,489,482 prepared bytes even with one-byte names; at least 26,317 retained payload records at
128 KiB writes against the 4,096-record registry; Round43's file-capacity FAIL, unexplained by its
labelled diagnostic PASS; and the unrun full prepared-tree upload, its one explicit full-upload Commit,
later incremental Commits and matched R6 / #207. The C1 three-fresh-directory cycle-validation suspicion
remains unconfirmed and untested.

Evidence in the committed packet: `core/docs/architecture/proposal/fuse-workspace-snapshot-overlay/49-fresh-file-streaming.md`
and `evidence/fresh-stream/{functional-index-02,captured-replay-failure-01,archive-manifest}.json`.

## Pair1 progress checkpoint — budget stop, 2026-09-22

The owner stopped further implementation because the budget was exhausted and requested a progress update, next-agent handoff, and commit of existing changes. This issue remains open. No push, merge, release admission or issue closure is implied.

### Completed since the prepared-symlink prerequisite

| Scope | Local commit | Actual verification |
| --- | --- | --- |
| Native Workspace symlink creation, local/captured Readlink, Commit integration and typed backing failure preservation | `9060c26bcc3e905e031415da20cec54352b94192` | 10 live selections / 19 checks passed on first attempts. The deliberately damaged backing case claims external teardown only. |
| Kernel SYMLINK and mounted SDK creation, checked entry coherence, retained notification failure/remount recovery and exact Readlink boundary | `74d4a2ace173d09689b8fbb42953658e94277bab` | Seven live selections / 14 checks passed on first attempts, with native clean close and normal teardown. |
| Fresh-file complete-content streaming prerequisite | `9499012926f661ce4a7b357b18810e76c3179806` | Product/caller reviews and required build/check commands passed. **All six registered live selections are NOT_RUN; zero attempts.** |

The fresh-file change selects complete `ConstructFile` streaming only for fresh, noncaptured regular files. Existing and captured-G edits retain the 8 MiB replay limit. Per-payload 8 MiB, FUSE/read 128 KiB, 1024 pieces, 256 edits, quota/window/worker/deadline limits are unchanged. No full-file resident buffer is added. A source cursor casts only after bounding in u64; 32-bit execution remains NOT_RUN.

For the current checkpoint: host 702 tests / 3 ignored; Linux 700 tests / 162 ignored; host/Linux all-target Clippy with warnings denied; fmt; binaries/examples; host/Linux product checks; the 255-file product boundary guard; and six boundary self-tests all passed. New Linux live tests remain ignored until run explicitly. Heavy commands were serial, Cargo jobs 2, Docker CPUs 2, construction worker 1.

### Prepared workload and immediate next step

The owner selected `npx @deepseek-ai/dsh web` and explicitly excluded network/npm installation from the test. The existing Linux preinstallation and pinned corpus are preserved. **The full tree has not been uploaded or committed.**

The next proof reuses the actual 18,259,144-byte `libvips-cpp.so.8.18.6` from that corpus (SHA-256 `264d3092d69de80f5acdb71c930efec8db5bd9627f41659ed3416566b9ae34b4`). The input copy and compiled tests are ready; the final immutable runner bundle still needs sealing. Selected cases cover actual FUSE upload → one ConstructFile/Commit → four-byte edit → second EditFile/Commit with complete digests, and captured-G replay limits. Four focused regressions are also registered. These are functional proofs with unknown cache state, not performance evidence.

### Remaining blockers

- Full upload needs 28,743 changed identities / 28,742 bindings, against current 128-entry admission. The current prepared representation requires at least 2,489,482 bytes even with one-byte names, against a 32 KiB request limit. Bounded indexed C1 input/working state, shared Service/Bridge delivery, C5 finalization and Workspace frontier/completion must evolve together.
- At least 26,317 retained payload records are needed at 128 KiB writes, against the current 4,096-record registry. Bounded backed ownership is still required. The 256-node lookup/handle pin limit also cannot be bypassed by fabricating kernel forgets.
- Complete prepared-tree upload, **one explicit full-upload Commit**, later incremental Commits and remaining app/shell qualification are unrun. No hidden smaller Commits or workload shrink is allowed.
- **Round43's file-capacity FAIL remains open.** Its diagnostic PASS did not close or replace it. Updating the now-obsolete fresh-file 8 MiB+1 assertion does not rewrite the historical failure.
- Matched R6 / #207 remains unrun, with no cold-cache, performance, RSS, durability or release qualification.
- A separate read-only C1 audit raised a possible three-fresh-directory cycle-validation gap. It is **unconfirmed and untested**, not an observed failure; reproduce it through the public API before making any claim or fix.

### Handoff and source accounting

Committed handoff prompt: `core/docs/architecture/proposal/fuse-workspace-snapshot-overlay/50-budget-stop-handoff.md`. It records the exact resume steps, binaries/fixtures, source seals, completed commands, NOT_RUN selections, cleanup qualifications and remaining dependencies.

Continue in `/Users/yifanxu/.codex/worktrees/795c/layerfs`, branch `codex/pair1-remote-mount`, at local checkpoint `9499012926f661ce4a7b357b18810e76c3179806`; the local commits have not been pushed. Preserve `core/target/pair1-evidence/`, including the prepared inputs and append-only receipts.

Production LOC (exact parent/final-staged snapshots, unchanged counter `b5b9617d08204977176302311e0b2c72a811b420`; product Rust/runtime SQL only, excluding tests/docs/tooling/fixtures):

- Native symlink47: 112586 → 112883 (**+297**); core 47169 → 47466; reference 65417 unchanged.
- Mounted symlink48: 112883 → 112949 (**+66**); core 47466 → 47532; reference unchanged.
- Fresh streaming49/handoff: 112949 → 112975 (**+26**); core 47532 → 47558; reference unchanged.

The formerly spinning PID11323 was terminated with explicit owner authorization. The shared cancellation-spin correction was committed earlier. Implementation agents are stopped; no task-owned build/test/daemon remained running at this checkpoint.

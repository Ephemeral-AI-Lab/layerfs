from pathlib import Path
import json,os,subprocess,time,hashlib
root=Path.cwd();p=root/'core/target/pair1-evidence/native-symlink'
freeze=json.loads((p/'source-freeze-02.json').read_text())
for name,digest in {**freeze['source_inputs_sha256'],**freeze['caller_inputs_sha256']}.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
env=os.environ.copy();env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None);env.update(CARGO_TARGET_DIR=str(root/'core/target'),CARGO_BUILD_JOBS='2',LAYERFS_CONSTRUCTION_WORKERS='1',DOCKER_CONTEXT='desktop-linux')
for name in ['host-test-01','host-clippy-01','linux-test-01','linux-clippy-01','fmt-01','boundary-01','boundary-selftest-01']:
 prev=json.loads((root/'core/target/pair1-evidence/prepared-symlinks/checks'/f'{name}-command.json').read_text());cmd=prev['command'];out=p/'checks'/f'{name}.log'
 with out.open('xb') as log:
  start=time.monotonic();r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);elapsed=time.monotonic()-start
 result=dict(name=name,command=cmd,exit_code=r.returncode,wall_seconds=elapsed,source_freeze='source-freeze-02.json')
 with (p/'checks'/f'{name}-command.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
